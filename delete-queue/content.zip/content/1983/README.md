**28 / 29 januari en 4 /5 februari 1983**

Nadat de astronauten in hun raket waren gelanceerd vanaf een immens platform en onder grote belangstelling werd door hen een bezoek gebracht aan achtereenvolgens Mars, de hel, Neptunes, hemel en Bachus. Tijdens deze uitstapjes werden ze onthaald met dans, muziek en diverse sketches. Tot slot arriveerden de astronauten tot opluchting van de bevolking weer in Aelse.


Sajelairinnekes en Sajelaire,
Onger deskundige begeleijing van professor Kos Mos zal
oos Sajelraket vél planeete aandoon.
Veer raoje uch aan, om uch veural bie de sjtart van.)
raket good vas te houwe. Veer houpe tussje elf en twelf
Geer hooft nao de lenjing neet in quarantaine.

Ger kent daonao nog ein paar oer gezellig danse op de
meziek van de Risto’s,

#### Technische Ploog
Decor:  Peter Hermans, Frits Beckers, Jos Driessen, Wil Bakker,
        Sjir Mullenders, Harrie Franssen, Ben Scheepers, Joep
        Houben, Chrit Vaassen, Peter Peters, Jan Vrancken, Graad
        Beckers, Piet Fredrix en Lei Spronckmans

Belichting: Hub Spronckmans jr.

Geluid: Jo Willems, Jos Verboort en Paul Drent

Rekwesieten: Wil Vaassen

Grime en Pruuke: Ruud Huynen, Annelies Muller-Bergs, Anja Beckers, Rut Lamers en Dimphy Beckers

Choreografie: Els Meijers en Dimphy Beckers

Toneelassistentie: Theo Paes

Video-opname: Peter Keulers

Foto’s: Harrie Verboort

Kleijaage: Dimphy Doornbos

Muzikaale begeleijing: de Risto’s
Zaalverseering: de Augustinussjwal

Regie: Hub Meijers en Lei Ummels

