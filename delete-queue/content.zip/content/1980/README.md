__18-19-20 januari 1980__

Deze revue laat de belevenissen zien van een gezelschap dat per bus door Europa trekt en hierbij diverse steden bezoekt. De reis gaat van Elsloo naar achtereenvolgens Kerkrade (schlagerfestival), Kufstein (camping), Valencia (orkest met dans, o.a. Sajelballet als een Spaanse rijschool olv Nic Voncken), Keulen (C.V. Rot-Weisz) en tenslotte retour in Elsloo (Wiener Sangerknaben).  Diverse bekende figuren uit het dorp doen aan deze revue mee. Te noemen hierbij valt o.a.: begrafenisondernemer Paul Daemen, raadslid (wethouder) Jacq Meijers, ex-wielrenner Henk Stevens, kantonnier Harie Steps, friteskraamhouder Sjefke Collard, middenstanders Nic Voncken en Jos van Hees.



