Een startend Partie service en verhuurbedrijf regelt feesten en partijen van A tot Z.
