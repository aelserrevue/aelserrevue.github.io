**10 / 11/ 17 / 18 februari 1984**

Om deze revue bij het Aelser publiek te promoten werd door de “hoofdrolspelers”  een tocht per paardenkoets door het dorp gemaakt. Onder de kop “Aelser revue in de steigers” verscheen een artikel met foto in de krant De Limburger. In dit artikel is tevens een korte beschrijving van de inhoud van de revue weer gegeven.

De regie van deze revue was in handen van Hub Meijers en Lei Ummels. Aan deze revue deden eveneens bekende dorpelingen mee. Te noemen valt hierbij Meister Gorissen (hoofd der school), Paul Daemen (begrafenisondernemer), Frens Dols, Jan Wilting en vele anderen.
