**29 / 30 januari en 5 / 6 februari 1982**
**Entree: 7,50 gulden**

't Aelser Revue-Gezelsjap prissenteert:

Sajelbwat 1982

Gesjreve, ineingesjteeld en geregisseerd door
Fons Meijers en Piet Ronden.
 

Beste Passagiers,

Kapitein Dobberman van de Sajelbwat hét uch alle-
maol van harte welkom op zien 4-oer doerende cruise
door ’t lentj van de humor.

Controleer effe of geer allemaol ’t Zwomdiploma bie

uch hébt, want ’t koos waal ins ein naate bedoening
waere (zwoawaal van bénne es van boete).

Ein gooi reis toegeweinsjt,
‘t Aelser Revue Comité

P.S. Zwemveste onger de banke.


#### Technische Ploog:
Regie : Fons Meijers en Piet Ronden

Decor : Peter Hermans, Jean Muller, Frits Beckers,
Joep Houben, Jos Driessen, Wil Bakker en
Raymond Simons.

Belichting : Hub Spronkmans Jr.

Geluid : Jo Willems - Jos Verboort

Rekwesieten : Willie Vaessen - Ruud Huynen

Grime : Linda Schrooders-Martens, Ruud Huynen

Choreografie : Roos Thomassen, Els Meijers, Riet v. Loenen.

Toneelassistentie : Ties Lemmens

Coiffures: Kapsalon Marlou

Video-opname : Peter Keulers

Kledingadviezen : Dimphy Doornbos

Muzikale begeleiding :  ‘t Aelser Revue orkes o.I.v. Jan Pluis, trompet
en gitaar; Geerling Brands, orgel; Louis Bec-
ers, bas; Louis Driessen, drum; Jac. Spronkmans, gitaar: Piet Renkens, percussion.

#### Programma-euverzich Sajelbwat 1982

19.40 oer   Hup Albert en zien "Toe maar Anita Ver-
            brassbent" in ’n Live-Concert op de
            Sajelbwat.

19.55 oer   Tot uch spruk ooze geistelijke adviseur
            Jean de Sjoester.

20.00 oer   ’t Anker weurt gelich veur ’n 4 oer doerende reis door ’t léntj van de Humor.

+24.00 oer : Nachbal mit PIET en FRANS (en uch allemaol)


Als afsluiting van deze revue werd als feestavond een bootreis georganiseerd.

Helaas ontstond er medio 1982 tussen de Sajelaire en het ARC onenigheid omtrent de organisatie van een nieuwe revue. Dit resulteerde in het opstappen van het ARC.
Op initiatief van de Sajelaire werden de voorbereidingen gestart om te komen tot een nieuwe revue, zijnde Sajel raket.

