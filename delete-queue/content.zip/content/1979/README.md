## 2e editie Aelser revue
**13 en 20 januari 1979**

Deze revue heeft haar naam te danken aan de destijds mateloos populaire ietwat pikante Tv serie  Waldolala. De presentator van deze serie was Waldo van Dungen, dus kreeg Hub Meijers als presentator van deze revue de naam Waldo. De revue werd 2 maal opgevoerd. De eerste keer in zaal Martens en vanwege de enorme belangstellig de tweede keer in het Maaslandcentrum. 
De toeschouwers waren in zaal Martens zo enthousiast dat ze de presentator Waldo aan het slot van de revue de mogelijkheid boden om lopende op de tafels van achter uit de zaal het podium te beklimmen. Dat hierbij een aantal bierglazen sneuvelden werd voor lief genomen.
Tijdens de scene van het orkest de “Londen Symphoniker” kwam Jacques Wintraecken met een fiets het toneel op.
De achterwand van hert decor bestond uit los staande spaanplaten van 120 x 240 cm. Hij knalde een spaanplaat omver die tot grote hilariteit van het publiek op de orkestleden viel. Gelukkig raakte niemand gewond bij deze niet voorziene  act.

Tijdens deze revue werd de carnavalsschlager 1979 gepresenteerd “In Aelse viere veer vastelaovend”, gezongen door Trees Aelmans-Hoeveler met begeleiding van De Maasgalmkapel o.l.v. Chrit Everaers.

#### Ideeén en teksten:
* Fons Meyers
* Piet Ronden
* Leo Ummels

#### Decor:
* Peter Hermans
* Jean Miller

#### Geluid:
* Jo Willems
* Louis Driessen

#### Belichting:
* Mart Meyers
* Hub Spronkmans

#### Rekwisieten:
* Willy Vaessen
* Roger Pepels
* Dimphy Doornbosch

#### Grime:
* Elly Roosen
* Ruud Huynen

#### Regie:
* Fons Meyers
* Piet Ronden

in samenwerking met de stichting LIMERO
