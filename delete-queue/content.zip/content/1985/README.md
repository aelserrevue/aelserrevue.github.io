**25/26 januari en 1/2 februari  1985**

In de TV-studio zorgt regisseur Snelbinder (René Snellings) ervoor dat hij samen met de scriptgirl Gemma (Marij Steps) en hulpregisseur Jupke (Roger Everaers) een vlekkeloze uitzending verzorgt. José Vossen treedt op als poetsvrouw. De beelden bestaan uit o.a. een aflevering van XY gelöszt, Hawaï, Indianen- en kozakkenscene, Romeo en Julia,  griezelscene, documentaire, slapstick enz. Muzikale medewerking werd verleend door de Sajelkapel.

