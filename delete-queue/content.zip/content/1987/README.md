**6 /7, 13 / 14 februari 1987**

Hub Meijers heeft het comité (ARC) inmiddels verlaten. De decorploeg bestaat uit de volgende personen: Peter Hermans, Graad Beckers, Ruud Lamers, Jan Wilting, Wil Doornbos, Ben Scheepers en Jan Feron . De grime en rekwisieten verzorging is de verantwoordelijkheid van Ruud Lamers. Als nieuwe revue kapel  gaat “Sjöt in “ optreden.

Als contactpersonen van de diverse groepen / disciplines traden op:D. Doornbos, M. Breuls, J. Penders, A. Broersma, P. Broersma, J. Fredrix, H. Reubsaet, G. Beckers, P. Lemmens, R. Lamers, J. Goossens, P. Hermans, L. Meijers en J. Willems.

