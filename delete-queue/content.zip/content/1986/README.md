**24/25 januari en 31 januari en 1 februari 1986**

Het overleg met de contactpersonen vond plaats in diverse cafés van Aelse te weten: jongerencentrum Utopia, zaal Taks, Maaslandcentrum, café Eussen en café “De Keigel”.
Als nieuw lid van het Comité werd Wim Hanssen verwelkomd.

[Medewerkers](/#/revue/1986/uploads/a53b01ac-abeb-4b72-9068-ab3a6aa6da7c)
