﻿"Ut Zetpilke" eine toepasselikke naam veur ein Medisch Zörg Centrum hè? 
Dit jaor numme veer uch mit nao de medische waereld. Ut Medisch Centrum is bezig mit ein verboewing, zwadat ut ein Medisch Zörg Centrum kent waere. 
Mit de aanboew van eine vleugel weurt d'r ein geslaote aafdeiling toegevoeg aan ut Medisch Centrum. 
Frau Doktor Helga von Flaushausen haet dan auch alles in wirking gesteld om de geslaote aafdeiling optied aaf te kriege, 
echter is ut boewbedrief ein belangriek element vergaete te make. 

De patiënte van de geslaote aafdeiling waere dan auch veur ein tiedje elders opgevange, mit alle gevolge van dien. 
Medicie motte waere opgeleid en dit geit in dit Medisch Zörg Centrum mit de bèste vakluuj, wie ein fluitje van eine cent. 
Uiteraard vènje de studente de praktijklèsse ut intresantste. 

Dit Medisch Zörg Centrum is van alle mèrte toes, zwa haet Frau Doktor Helga von Flaushausen eine vakkundige plastische chirurg in deens genomme. 
Deze chirurg haet die fiene kneepkes van ut vak veural geljaerd door väöl praktijk ervaring opgedaon te höbbe bie Robert Schoemacher. 
Ut vakkundige verplegend personeel haet de persoonlikke verzörging whag in ut vaandel staon, mesjien hiej en dao waal get te whag in ut vaandel. 
Zwa wie eeder ziekehoes beaamd zin d'r natuurlik intriges tösje ut personeel, patiënte en anger aanverwante artikele. 
D'r waere uch jèl gèt hilarische, mesjien waal herkenbare, situaties veurgesjoteld vanaovend meistal mit eine lach mèr auch mit ein traon. 

Bie ut Medisch Zörg Centrum zal neet alles op rölkes laupe, mèr ze doon hun bès uch zwa snel meugelik op ein deskundigge maneer te helpe, 
zwadat g'r mit ein pilke of zuifke van bie "Jaezeker de Apotheker" zwa weer opgeknap zeet. 
Zit geer neet good in uch vel, wèt geer neet wae bie uch ut mènke of ut vruijke is? Auch dit kènt waere opgelos in os Medisch Zörg Centrum. 
De plastische chirurg en de gynaecoloog höbbe ein samewirkingsverband en sleutele alles op de gooj maneer aanein. 
Kortom genog ingrediënte veur eine aovend spas en plezeer. 

Maonje lank zin weer 96 vriewilligers bezig gewaes om veur uch eine aovend in ein te stele. Veer weite allemaol dat vriewillers tegewoordig ein oetstervend ras is, mèr gelökkig höbbe vr nog genog van die gekke rondjlaupe die dit es eine hobby zeen. Allemaol amateurs op dit gebied, dit wil v'r nog mèr ens extra benumme. Dat weurt dèkker vergaete, dat (bienao) geine van dees vriewilligers ein opleiding veur dit haet gehad en al gaaroets neet betaald weurt veur al dit werk. 
Uch applaus en waardering is veur dees luuj ut grwoatste good in deze. D'r zin weer tekste gesjreve, maonje gerepeteerd, decors geboewd en gesjildert, danspèskes, leedjes ingestudeerd, kleijer genjeijd, meziekstökke gesjreeve, leegh en geluidsplanne gemaak, pruuke gekap, grime oetgezeuk enz enz, mèr veural auch väöl gelache, want dae veurspas wat veer van te veure höbbe is goud waerd. Jonk en oud steit weer op de buun, of is achter de sjèrme aktief. 
Mit ozze auwtste mitwirker van 88 jaor, ozze auwtste teksspeler van 79 jaor en os jongste mitwirkers van 16 jaor, zin v'r grwètsj op deese fantastische revue femilie. Sinds ein jaor of 9 zin v'r eine waeg ingeslage om dit evenement door te gaeve aan ein jonger generatie. Es ste gèt wils behouwe dan zal dat auch motte. Dit geit neet van allein, blood, zweit en zeker soms auch traone kos dat, mèr dat is ut allemaol waerd. Kortom d'r is koste nog meujte gespaart om d'r auch dit jaor weer eine echte Aelser-Revue van te make.