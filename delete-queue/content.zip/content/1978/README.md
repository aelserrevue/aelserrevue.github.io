De carnavalsvereniging verkeerde in zwaar weer en er was eigenlijk geen geld voor (carnavals) activiteiten te organiseren. Dus kwamen 3 Elsloonaren, alle drie zittend als lid van de Sajelaire, op het idee om een bonte avond te organiseren met artiesten (mensen) vanuit het dorp. Er werden sketches geschreven, gezongen, muziek gemaakt en gedanst. Dit was meteen een groot succes een uitverkochte zaal bij zaal Raven aan de Stationsstraat.

Er was dus toen nog geen naam voor de bonte avond het werd ook nog niet een revue genoemd, dit kwam vervolgens in 1979 pas aan bod.

Uit de weinige beelden die nog beschikbaar zijn kan worden afgeleid dat de volgende acts werden uitgevoerd door benoemde 1e Uitvoering: Aelser Revue, bonte avond in 1978


Buut door Hub Meijers en Chris Stevens; Chris stond niet op het programma, maar meldde tijdens de voorstelling dat hij ook een buut wilde brengen
Little Ernie and the Shakers (groep uit het voormalig Utopia, met o.a. Hub Penders, Jan Feron, Jack Fredrix (pep), Jos Meijers en Jos Huynen.
Bokswedstrijd “Black against White” tussen Joep Bohlem en Jacques Wintraecken. Jack Spronckmans ( beter bekend als Jacquelientje) was de vertederende rondemiss.
Jongerengroep Gojo uit Sittard (Jongerengroep Escolum meldde zich enkele dagen voor de uitvoering af)
De Stieve Prengel
Wielerwedstrijd op rollers: Jos Meijers tegen Henk Stevens  met commentaar van Jack Meijers.
Het Russisch Staatsballet, bestaande uit Graad Beckers, Pierre Lemmens, Albert Philips en Fons Meijers.
Toneelgroep Pallieter, met o.a. Jacques Fredrix, Annelies Bergs en Ine Pesch.

