Tijdens deze revue werd het Revue lied gepresenteerd.

Deze revue laat zien hoe TV opnames van de scenes worden gemaakt. Opname cineast is Jo Eijkenboom. 
Scenes die o.a. worden gespeeld zijn: wandeltocht met raadslid / wethouder Sjef Palmen als medewerker controlepost, kleedkamer, weerbericht (a la Armand Pien van de BRT), zanggroep Escolum.

In het najaar van 1981 werd na overleg met de Sajelaire een revue comité(ARC) in het leven geroepen.
Dit bestond uit de volgende leden: 
* Fons Meijers (voorzitter)
* Piet Ronden (vice-voorzitter)
* Sjir Mullenders (coördinator)
* Gré Huskens (secretaris-penningmeester)
* Peter Hermans (techniek)
* Willy Vaessen (namens Sajelaire)
* Jo Collard (zanggroep Escolum geluid)
* René Snellings (coördinator)

Peter Hermans ontwierp het logo (vignet) van de Aelser revue; **“Aelser revue, sjiek nondedjuu”**